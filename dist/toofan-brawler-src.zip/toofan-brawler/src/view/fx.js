/* view: short-lived effects. Currently the guitar's sonic boom: staggered shock rings that fly out from the guitar. */
'use strict';

function createFx(scene) {
  var flip = 0; function i0() { return (flip++ & 1) ? 0xffffff : 0xffc21a; }
  var items = [], torus = new THREE.TorusGeometry(1, 0.07, 8, 40), disc = new THREE.RingGeometry(0.2, 1, 40), flashGeo = new THREE.SphereGeometry(0.5, 12, 8);
  function mat(color, op) { return new THREE.MeshBasicMaterial({ color: color, transparent: true, opacity: op, depthWrite: false, side: THREE.DoubleSide }); }
  function add(mesh, life, grow, delay, from) { mesh.visible = false; scene.add(mesh); items.push({ m: mesh, life: life, age: -delay, grow: grow, from: from, op: mesh.material.opacity }); }
  /* blood and sweat: tiny voxel-sized droplets thrown outward, falling under gravity; blood leaves a stain that fades */
  var bits = [], stains = [], bitGeo = new THREE.BoxGeometry(0.035, 0.035, 0.035), stainGeo = new THREE.CircleGeometry(0.5, 10);
  var bitMats = { blood: [0x8e0f10, 0xb3161a, 0x6a0a0c].map(function (c) { return new THREE.MeshBasicMaterial({ color: c }); }), sweat: [0xd6efff, 0xffffff].map(function (c) { return new THREE.MeshBasicMaterial({ color: c, transparent: true, opacity: 0.85 }); }) };
  var stainMat = new THREE.MeshBasicMaterial({ color: 0x4a0709, transparent: true, opacity: 0.7, depthWrite: false });
  var seedN = 1; function rnd() { seedN = (seedN * 1664525 + 1013904223) >>> 0; return seedN / 4294967296; }
  function drops(kind, o, dirx, dirz, n, power) {
    var mats = bitMats[kind];
    for (var i = 0; i < n && bits.length < 160; i++) {
      var m = new THREE.Mesh(bitGeo, mats[i % mats.length]), sp = (kind === 'blood' ? 2.2 : 1.7) * (0.5 + rnd()) * (0.7 + power * 0.8), spread = 1.4;
      m.position.set(o.x, o.y, o.z); var sc = kind === 'blood' ? 0.8 + rnd() * 1.2 : 0.6 + rnd() * 0.7; m.scale.setScalar(sc); scene.add(m);
      bits.push({ m: m, vx: dirx * sp + (rnd() - 0.5) * spread, vy: 1.2 + rnd() * 2.0, vz: dirz * sp + (rnd() - 0.5) * spread, blood: kind === 'blood' });
    }
  }
  var api = {
    /* blood / sweat burst at o, thrown along (dirx, dirz); power 0..1 */
    droplets: function (kind, o, dirx, dirz, n, power) { drops(kind, o, dirx, dirz, n, power || 0); },
    /* origin: world position, yaw: hero facing (radians, 0 = +z) */
    spawn: function (kind, origin, yaw) {
      if (kind === 'whirl') {                                   /* cyclone ring around the spinning hero */
        var w = new THREE.Mesh(torus, mat(i0(), 0.8)); w.position.set(origin.x, 1.15, origin.z); w.rotation.x = Math.PI / 2; add(w, 0.5, 3.4, 0, 1.0);
        return;
      }
      if (kind === 'slam') {                                    /* guitar driven into the ground */
        [0xffc21a, 0xffffff, 0x4fa3ff].forEach(function (c, j) {
          var g2 = new THREE.Mesh(disc, mat(c, 0.85)); g2.position.set(origin.x, 0.04 + j * 0.01, origin.z); g2.rotation.x = -Math.PI / 2; add(g2, 0.9, 9 + j * 2, j * 0.08, 0.3);
        });
        var up = new THREE.Mesh(flashGeo, mat(0xffffff, 0.9)); up.position.set(origin.x, 0.4, origin.z); add(up, 0.3, 5, 0, 0.5);
        return;
      }
      if (kind === 'spark' || kind === 'blockspark') {            /* impact flash: warm for a hit, blue for a block */
        var c1 = kind === 'spark' ? 0xfff2b0 : 0x7fb8ff, c2 = kind === 'spark' ? 0xff9a1a : 0xffffff;
        var fl = new THREE.Mesh(flashGeo, mat(c1, 0.95)); fl.position.set(origin.x, origin.y, origin.z); add(fl, 0.12, 0.75 + (yaw || 0) * 0.5, 0, 0.2);
        var rg = new THREE.Mesh(torus, mat(c2, 0.9)); rg.position.set(origin.x, origin.y, origin.z); rg.rotation.set(Math.random() * 3, Math.random() * 3, 0); add(rg, 0.16, 0.45, 0, 0.1);
        return;
      }
      if (kind !== 'boom') return;
      var cols = [0xffc21a, 0x4fa3ff, 0xffffff, 0xffc21a];
      for (var i = 0; i < 4; i++) {
        var r = new THREE.Mesh(torus, mat(cols[i], 0.95));
        r.position.copy(origin); r.rotation.y = yaw; r.userData.off = i;
        add(r, 0.75, 7.5, i * 0.09, 0.25);
      }
      var g = new THREE.Mesh(disc, mat(0xffe28a, 0.7)); g.position.set(origin.x, 0.03, origin.z); g.rotation.x = -Math.PI / 2; add(g, 0.7, 6, 0, 0.3);
      var f = new THREE.Mesh(flashGeo, mat(0xffffff, 0.9)); f.position.copy(origin); add(f, 0.22, 2.4, 0, 0.5);
    },
    update: function (dt) {
      for (var b = bits.length - 1; b >= 0; b--) {
        var bt = bits[b]; bt.vy -= 9.5 * dt; bt.m.position.x += bt.vx * dt; bt.m.position.y += bt.vy * dt; bt.m.position.z += bt.vz * dt;
        if (bt.m.position.y <= 0.03) {
          if (bt.blood && stains.length < 40) { var st = new THREE.Mesh(stainGeo, stainMat.clone()); st.rotation.x = -Math.PI / 2; st.position.set(bt.m.position.x, 0.025, bt.m.position.z); st.scale.setScalar(0.05 + rnd() * 0.1); scene.add(st); stains.push({ m: st, age: 0 }); }
          scene.remove(bt.m); bits.splice(b, 1);
        }
      }
      for (var q = stains.length - 1; q >= 0; q--) {
        var sn = stains[q]; sn.age += dt; if (sn.age > 12) { scene.remove(sn.m); sn.m.material.dispose(); stains.splice(q, 1); continue; }
        sn.m.material.opacity = 0.7 * Math.min(1, (12 - sn.age) / 4);
      }
      for (var i = items.length - 1; i >= 0; i--) {
        var it = items[i]; it.age += dt;
        if (it.age < 0) continue;
        var u = it.age / it.life;
        if (u >= 1) { scene.remove(it.m); it.m.material.dispose(); items.splice(i, 1); continue; }
        it.m.visible = true;
        var e = 1 - Math.pow(1 - u, 2.2), s = it.from + (it.grow - it.from) * e;
        it.m.scale.set(s, s, s); it.m.material.opacity = it.op * (1 - u) * (1 - u * 0.3);
      }
    },
    active: function () { return items.length + bits.length; },
    dispose: function () { items.forEach(function (it) { scene.remove(it.m); it.m.material.dispose(); }); items.length = 0; bits.forEach(function (x) { scene.remove(x.m); }); stains.forEach(function (x) { scene.remove(x.m); x.m.material.dispose(); }); bits.length = 0; stains.length = 0; bitGeo.dispose(); stainGeo.dispose(); torus.dispose(); disc.dispose(); flashGeo.dispose(); }
  };
  return api;
}

module.exports = { createFx: createFx };
