/* view: draws the thugs from the simulation. One rig per enemy; poses come from the same keyframed moves as the hero.
   A glowing marker over the head is the attack telegraph: white while winding up, yellow, then red just before the strike
   (red and larger for an unblockable swing). */
'use strict';

var herorig = require('./herorig');
var posemath = require('./posemath');
var moveplayer = require('./moveplayer');
var moves = require('../data/moves');
var enemies = require('../data/enemies');

/* how a man's body answers each kind of blow: head and torso snap the way the blow sends them (degrees, metres) */
var REACT = {
  jab: { 'head.rx': -16, 'neck.rx': -6, 'spine.rx': -8 }, cross: { 'head.rx': -20, 'head.ry': -16, 'spine.rx': -10, 'spine.ry': -12 },
  elbow: { 'head.ry': -36, 'spine.ry': -18, 'spine.rz': 8, 'head.rz': 8 },
  hookB: { 'head.ry': 52, 'neck.ry': 22, 'spine.rz': -12, 'spine.ry': 16 }, hook: { 'head.ry': -52, 'neck.ry': -22, 'spine.rz': 12, 'spine.ry': -16 },
  uppercut: { 'head.rx': -40, 'neck.rx': -20, 'spine.rx': -22, 'hip.y': 0.04 }, axeKick: { 'head.rx': 34, 'neck.rx': 22, 'spine.rx': 36, 'hip.y': -0.15 },
  knee: { 'spine.rx': 46, 'hip.rx': 22, 'head.rx': 22, 'hip.y': -0.08 }, roundhouse: { 'head.ry': 66, 'spine.rz': 16, 'spine.ry': 24, 'hip.ry': 18 },
  kick: { 'spine.rx': -26, 'hip.z': -0.08, 'head.rx': -14 }, counterCross: { 'head.rx': -24, 'head.ry': 24, 'spine.rx': -16 },
  counter: { 'spine.rx': -32, 'head.rx': -30, 'hip.y': -0.1 }
};
function addTo(out, add, k) { for (var n in add) out[n] = (out[n] || 0) + add[n] * k; }

function createEnemyView(scene) {
  var views = {}, TPS = 60;
  var markGeo = new THREE.SphereGeometry(0.11, 10, 8), clubGeo = new THREE.BoxGeometry(0.07, 0.8, 0.07), clubMat = new THREE.MeshLambertMaterial({ color: 0x6b4423 });
  var shadowGeo = new THREE.CircleGeometry(0.5, 20), shadowMat = new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.28, depthWrite: false });
  function make(e) {
    var rig = herorig.createHeroRig('thug'), mark = new THREE.Mesh(markGeo, new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0, depthTest: false }));
    mark.renderOrder = 12; mark.position.y = 2.15; rig.root.add(mark);
    var sh = new THREE.Mesh(shadowGeo, shadowMat); sh.rotation.x = -Math.PI / 2; sh.position.y = 0.02; rig.root.add(sh);
    if (e.kind === 'stick') { var club = new THREE.Mesh(clubGeo, clubMat); club.position.set(0, -0.12, 0.1); rig.parts.R.wrist.add(club); rig.root.scale.setScalar(1.08); }
    scene.add(rig.root);
    return { rig: rig, mark: mark, shadow: sh, cur: posemath.named('stand'), face: e.face, t: Math.random() * 6, sink: 0 };
  }
  function pose(e, v, dt) {
    var K = enemies.KINDS[e.kind], mv = moves.MOVES[K.clip], base;
    if (e.st === 'approach') base = e.moving ? posemath.walkPose(e.phase * 0.9, 0.9) : posemath.layer(posemath.idlePose(v.t), posemath.named('guard'), 0.3, 1, 1, 1);
    else base = posemath.layer(posemath.idlePose(v.t), posemath.named('guard'), 0.4, 1, 1, 1);
    var out = base;
    if (e.guarding) {
      /* arms up; each blow he soaks makes it worse: the first jolts him and sags the guard, the second nearly folds it */
      out = posemath.layer(base, posemath.named('block'), 0.25, 1, 1, 1);
      var gh = e.guardHits || 0, jolt = Math.exp(-Math.max(0, e.blockT) / 9) * (e.blockT < 40 ? 1 : 0);
      addTo(out, { 'spine.rx': -(6 + 12 * gh), 'head.rx': -(4 + 8 * gh), 'hip.z': -0.03 - 0.04 * gh }, jolt);
      addTo(out, { 'armA.sx': -16, 'armB.sx': -16, 'armA.sz': 10, 'armB.sz': 10, 'armA.e': 12, 'armB.e': 12, 'hip.y': -0.03, 'spine.rz': gh ? 5 : 0 }, gh * 1.0);
      if (gh) { out['armA.sz'] = (out['armA.sz'] || 0) + Math.sin(v.t * 40) * 3 * jolt; out['armB.sz'] = (out['armB.sz'] || 0) - Math.sin(v.t * 40) * 3 * jolt; }      /* arms shaking under the strain */
    }
    if (e.st === 'windup' || e.st === 'strike' || e.st === 'recover') {
      var u = e.st === 'windup' ? Math.min(1, e.t / (K.windup * TPS)) : 1;
      var ct = e.st === 'windup' ? u * mv.hit * 0.95 : mv.hit * 0.95 + Math.min(1, (e.st === 'strike' ? e.t : 8 + e.t) / 30) * (mv.len - mv.hit * 0.95);
      /* anticipation: lean back before the swing */
      var clip = moveplayer.clipPose(K.clip, ct), w = e.st === 'recover' ? Math.max(0, 1 - e.t / (K.recover * TPS * 0.6)) : 1;
      out = posemath.layer(base, clip, w, w, w, w);
      if (e.st === 'windup') { out['spine.rx'] = (out['spine.rx'] || 0) - 10 * u; }
    } else if (e.st === 'guardbreak') {
      /* the guard is smashed open: arms flung wide, head and chest thrown back, a stagger on the spot */
      var gb = Math.min(1, e.t / 6) * (1 - Math.max(0, (e.t - 36) / 20)); out = posemath.copy(base);
      addTo(out, { 'armA.sx': -30, 'armB.sx': -30, 'armA.sz': 70, 'armB.sz': 70, 'armA.e': -30, 'armB.e': -30, 'spine.rx': -26, 'head.rx': -30, 'hip.rx': -8, 'hip.y': -0.06, 'legA.hx': 12, 'legB.hx': -10 }, gb);
    } else if (e.st === 'hurt') {
      /* per-blow reaction: snaps in fast, eases back; the body twists the way that blow sends it */
      var jt = e.t < 4 ? e.t / 4 : Math.exp(-(e.t - 4) / 13); out = posemath.copy(base);
      addTo(out, REACT[e.lastMove] || REACT.jab, jt); addTo(out, { 'armA.sx': -20, 'armB.sx': -14, 'armA.sz': 14, 'armB.sz': 12, 'hip.y': -0.03 }, jt);
    } else if (e.st === 'down' || e.st === 'dead') {
      var dw = Math.min(1, e.t / 12); out = posemath.layer(base, posemath.named('down'), dw, dw, dw, dw);
    } else if (e.st === 'getup') {
      var gw = 1 - Math.min(1, e.t / 30); out = posemath.layer(base, posemath.named('down'), gw, gw, gw, gw);
    }
    posemath.approach(v.cur, out, 22, dt);
    return v.cur;
  }
  return {
    sync: function (list, alpha, dt) {
      var seen = {};
      for (var i = 0; i < list.length; i++) {
        var e = list[i], v = views[e.id] || (views[e.id] = make(e)); seen[e.id] = 1; v.t += dt;
        var x = e.px + (e.x - e.px) * alpha, z = e.pz + (e.z - e.pz) * alpha;
        var dy = Math.atan2(Math.sin(e.face - v.face), Math.cos(e.face - v.face)); v.face += dy * (1 - Math.exp(-14 * dt));
        var lying = e.st === 'down' || e.st === 'dead';
        v.rig.root.position.set(x, 0, z); v.rig.root.rotation.y = v.face;
        v.rig.applyPose(pose(e, v, dt), { plant: true }); v.rig.flutter(v.t, 0);
        if (e.st === 'dead' && e.t > 55) { v.sink = Math.min(1, (e.t - 55) / 45); v.rig.root.position.y = -v.sink * 0.9; }
        /* telegraph */
        var m = v.mark, K = enemies.KINDS[e.kind];
        if (e.st === 'windup') {
          var u = e.t / (K.windup * TPS), col = !K.blockable ? 0xff3322 : (u < 0.45 ? 0xffffff : (u < 0.8 ? 0xffd21a : 0xff3322));
          m.material.color.setHex(col); m.material.opacity = 0.95; var sc = (K.blockable ? 1 : 1.6) * (0.7 + 0.8 * u); m.scale.setScalar(sc);
        } else if (e.guarding) { m.material.color.setHex(0x4fa3ff); m.material.opacity = 0.75; m.scale.setScalar(0.8); }
        else m.material.opacity = 0;
        v.shadow.visible = !lying || e.t < 60;
      }
      for (var id in views) if (!seen[id]) { scene.remove(views[id].rig.root); delete views[id]; }
    },
    count: function () { return Object.keys(views).length; },
    dispose: function () { for (var id in views) scene.remove(views[id].rig.root); views = {}; }
  };
}

module.exports = { createEnemyView: createEnemyView };
